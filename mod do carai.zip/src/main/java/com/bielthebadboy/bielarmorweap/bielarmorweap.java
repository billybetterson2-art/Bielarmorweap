package com.bielthebadboy.bielarmorweap; // Ajuste para o seu pacote se for diferente!

import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

// Altere o pacote se suas classes de espada estiverem em outra pasta (ex: .items.DemonBloodSword)
import com.bielthebadboy.bielarmorweap.DemonBloodSword;
import com.bielthebadboy.bielarmorweap.GrassSword;

@Mod(modid = bielarmorweap.MODID, name = bielarmorweap.NAME, version = bielarmorweap.VERSION)
@Mod.EventBusSubscriber
public class bielarmorweap {
    
    public static final String MODID = "bielmod"; // ID do mod sempre em minúsculo
    public static final String NAME = "Biel's Armor & Weapons Mod";
    public static final String VERSION = "1.0";

    // Declarando as variáveis usando o tipo das suas classes personalizadas
    public static DemonBloodSword swordDemonBlood;
    public static GrassSword swordGrass;

    @EventHandler
    public void preInit(net.minecraftforge.fml.common.event.FMLPreInitializationEvent event) {
        // Inicializa as espadas passando o nome do registro e a aba do criativo
        swordDemonBlood = new DemonBloodSword();
        swordDemonBlood.setRegistryName("demon_blood_sword");
        swordDemonBlood.setUnlocalizedName("demon_blood_sword");
        swordDemonBlood.setCreativeTab(CreativeTabs.COMBAT);

        swordGrass = new GrassSword();
        swordGrass.setRegistryName("grass_sword");
        swordGrass.setUnlocalizedName("grass_sword");
        swordGrass.setCreativeTab(CreativeTabs.COMBAT);
    }

    // O evento que faz o Forge registrar tudo de verdade no jogo
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(
            swordDemonBlood,
            swordGrass
        );
    }
}
