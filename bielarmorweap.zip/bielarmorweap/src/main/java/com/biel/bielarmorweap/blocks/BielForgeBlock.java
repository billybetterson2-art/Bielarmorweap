package com.example.examplemod.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;
import net.minecraft.creativetab.CreativeTabs;

public class BielForgeBlock extends Block {

    public BielForgeBlock() {
        super(Material.WOOD); // Feito de madeira
        this.setUnlocalizedName("biel_forge");
        this.setRegistryName("biel_forge");
        this.setHardness(2.5F); // Tempo de quebra parecido com a Crafting Table
        this.setCreativeTab(CreativeTabs.DECORATIONS); // Aba de decorações do criativo
    }

    // Onde a mágica acontece: Quando o jogador clica com o botão direito no bloco
    @Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (worldIn.isRemote) {
            return true;
        } else {
            // Abre o menu de craft clássico, mas personalizado com o nome da sua forja!
            playerIn.displayGui(new InterfaceBielForge(worldIn, pos));
            return true;
        }
    }

    // Classe interna que "engana" o jogo para abrir o menu de Crafting Table
    public static class InterfaceBielForge implements IInteractionObject {
        private final World world;
        private final BlockPos position;

        public InterfaceBielForge(World worldIn, BlockPos pos) {
            this.world = worldIn;
            this.position = pos;
        }

        @Override
        public String getName() {
            return "biel_forge";
        }

        @Override
        public boolean hasCustomName() {
            return false;
        }

        @Override
        public net.minecraft.util.text.ITextComponentgetDisplayName() {
            return new TextComponentTranslation("container.biel_forge");
        }

        @Override
        public Container createContainer(InventoryPlayer playerInventory, EntityPlayer playerIn) {
            return new ContainerWorkbench(playerInventory, this.world, this.position) {
                @Override
                public boolean canInteractWith(EntityPlayer playerIn) {
                    return true;
                }
            };
        }

        @Override
        public String getGuiID() {
            return "minecraft:crafting_table";
        }
    }
}
