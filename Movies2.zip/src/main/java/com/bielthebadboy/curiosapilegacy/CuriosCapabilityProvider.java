package com.bielthebadboy.curiosapilegacy;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

public class CuriosCapabilityProvider implements ICapabilitySerializable<NBTTagCompound> {

    @CapabilityInject(ICuriosInventory.class)
    public static final Capability<ICuriosInventory> CURIOS_INVENTORY_CAP = null;

    private final ICuriosInventory instance = CURIOS_INVENTORY_CAP.getDefaultInstance();

    @Override
    public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
        return capability == CURIOS_INVENTORY_CAP;
    }

    @Override
    public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
        return capability == CURIOS_INVENTORY_CAP ? CURIOS_INVENTORY_CAP.cast(this.instance) : null;
    }

    @Override
    public NBTTagCompound serializeNBT() {
        return (NBTTagCompound) CURIOS_INVENTORY_CAP.getStorage().writeNBT(CURIOS_INVENTORY_CAP, this.instance, null);
    }

    @Override
    public void deserializeNBT(NBTTagCompound nbt) {
        CURIOS_INVENTORY_CAP.getStorage().readNBT(CURIOS_INVENTORY_CAP, this.instance, null, nbt);
    }
}
