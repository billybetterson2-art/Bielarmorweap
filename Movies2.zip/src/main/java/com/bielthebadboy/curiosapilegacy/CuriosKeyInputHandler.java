package com.bielthebadboy.curiosapilegacy;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = CuriosApiLegacy.MODID, value = Side.CLIENT)
public class CuriosKeyInputHandler {

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (CuriosKeybindings.openCuriosGuiKey.isPressed()) {
            EntityPlayer player = Minecraft.getMinecraft().player;
            World world = Minecraft.getMinecraft().world;
            
            if (player != null && world != null) {
                // Opens the custom inventory screen using the ID registered in GuiHandler
                player.openGui(CuriosApiLegacy.MODID, CuriosGuiHandler.CURIOS_GUI_ID, world, (int) player.posX, (int) player.posY, (int) player.posZ);
            }
        }
    }
}
