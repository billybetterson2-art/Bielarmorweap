package com.bielthebadboy.curiosapilegacy;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = CuriosApiLegacy.MODID)
public class CuriosEventHandler {

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof EntityPlayer) {
            // Attaches the custom slots to every single player entity
            event.addCapability(new ResourceLocation(CuriosApiLegacy.MODID, "curios_slots"), new CuriosCapabilityProvider());
        }
    }
}
