package com.bielthebadboy.curiosapilegacy;

import net.minecraftforge.items.IItemHandlerModifiable;

public interface ICuriosInventory extends IItemHandlerModifiable {
    // This interface allows expansion for custom accessory logic later
}
