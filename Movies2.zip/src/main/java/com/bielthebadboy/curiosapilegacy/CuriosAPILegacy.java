package com.bielthebadboy.curiosapilegacy;

import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;

@Mod(modid = CuriosApiLegacy.MODID, name = CuriosApiLegacy.NAME, version = CuriosApiLegacy.VERSION)
public class CuriosApiLegacy {
    
    public static final String MODID = "curios_api_legacy";
    public static final String NAME = "Curios API Legacy";
    public static final String VERSION = "1.0.0";

    public static Logger logger;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        logger.info("Initializing Pre-Initialization phase for " + NAME);
        
        // Registering the custom slots capability system
        CapabilityManager.INSTANCE.register(ICuriosInventory.class, new CuriosInventoryStorage(), CuriosInventory::new);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        logger.info("Initializing Initialization phase for " + NAME);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        logger.info(NAME + " successfully loaded by BieltheBadboy!");
    }
}

