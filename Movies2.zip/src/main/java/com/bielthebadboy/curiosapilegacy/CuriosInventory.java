package com.bielthebadboy.curiosapilegacy;

import net.minecraftforge.items.ItemStackHandler;

public class CuriosInventory extends ItemStackHandler implements ICuriosInventory {
    
    // Setting up 8 custom accessory slots as a starting point
    public CuriosInventory() {
        super(8);
    }
}
