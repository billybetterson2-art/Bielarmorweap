package com.bielthebadboy.curiosapilegacy;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.Capability.IStorage;

public class CuriosInventoryStorage implements IStorage<ICuriosInventory> {

    @Override
    public NBTBase writeNBT(Capability<ICuriosInventory> capability, ICuriosInventory instance, EnumFacing side) {
        if (instance instanceof CuriosInventory) {
            return ((CuriosInventory) instance).serializeNBT();
        }
        return new NBTTagCompound();
    }

    @Override
    public void readNBT(Capability<ICuriosInventory> capability, ICuriosInventory instance, EnumFacing side, NBTBase nbt) {
        if (instance instanceof CuriosInventory && nbt instanceof NBTTagCompound) {
            ((CuriosInventory) instance).deserializeNBT((NBTTagCompound) nbt);
        }
    }
}
