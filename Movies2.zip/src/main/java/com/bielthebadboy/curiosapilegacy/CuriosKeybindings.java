package com.bielthebadboy.curiosapilegacy;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

public class CuriosKeybindings {

    public static KeyBinding openCuriosGuiKey;

    public static void init() {
        // Sets 'C' as the default key to open your custom accessory inventory
        openCuriosGuiKey = new KeyBinding("key.curios_legacy.open", Keyboard.KEY_C, "key.categories.curios_legacy");
        ClientRegistry.registerKeyBinding(openCuriosGuiKey);
    }
}
