package com.bielthebadboy.curiosapilegacy;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class CuriosGuiHandler implements IGuiHandler {

    public static final int CURIOS_GUI_ID = 1;

    @Override
    public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        if (ID == CURIOS_GUI_ID) {
            return new ContainerCurios(player);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        if (ID == CURIOS_GUI_ID) {
            return new GuiCurios(player);
        }
        return null;
    }
}
