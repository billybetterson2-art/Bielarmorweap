package com.bielthebadboy.curiosapilegacy;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.GlStateManager;

public class GuiCurios extends GuiContainer {

    // Caminho para a textura da sua GUI (coloque sua imagem em assets/modid/textures/gui/curios.png)
    private static final ResourceLocation TEXTURE = new ResourceLocation("modid", "textures/gui/inventory.png");

    public GuiCurios(EntityPlayer player) {
        // Passa o container do jogador para a superclasse da GUI
        super(new ContainerCurios(player));
        
        // Define o tamanho padrão da tela de inventário do Minecraft
        this.xSize = 176;
        this.ySize = 166;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.renderHoveredToolTip(mouseX, mouseY);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        // Renderiza a textura de fundo da GUI na tela
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        this.mc.getTextureManager().bindTexture(TEXTURE);
        
        int x = (this.width - this.xSize) / 2;
        int y = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
    }
}
