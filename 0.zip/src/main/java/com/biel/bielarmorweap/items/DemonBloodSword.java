package com.example.examplemod.items;

import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import net.minecraft.creativetab.CreativeTabs;

public class DemonBloodSword extends ItemSword {

    public DemonBloodSword(ToolMaterial material) {
        super(material);
        this.setUnlocalizedName("demon_blood_sword");
        this.setRegistryName("demon_blood_sword");
        this.setCreativeTab(CreativeTabs.COMBAT);
    }

    // Efeito de RPG: Roubo de Vida (Lifesteal) ao atacar
    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        // Ao acertar o monstro, o atacante ganha Regeneração I por 2 segundos (40 ticks)
        attacker.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 40, 0));
        
        // Coloca o monstro em chamas por 3 segundos (afinal, é sangue de demônio!)
        target.setFire(3);
        
        return super.hitEntity(stack, target, attacker);
    }
}
