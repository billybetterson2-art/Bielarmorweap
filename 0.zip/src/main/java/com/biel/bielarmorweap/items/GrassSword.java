package com.example.examplemod.items;

import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.Enchantments;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.creativetab.CreativeTabs;

public class GrassSword extends ItemSword {

    public GrassSword(ToolMaterial material) {
        super(material);
        this.setUnlocalizedName("grass_sword");
        this.setRegistryName("grass_sword");
        // Coloca o item na aba de combate do criativo
        this.setCreativeTab(CreativeTabs.COMBAT);
    }

    // RPG Effect: Poison on hit
    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        target.addPotionEffect(new PotionEffect(MobEffects.POISON, 100, 0)); // 5 seconds of poison
        return super.hitEntity(stack, target, attacker);
    }

    // Adventure Time Effect: Curse of Binding
    @Override
    public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean isSelected) {
        if (!stack.isItemEnchanted()) {
            stack.addEnchantment(Enchantments.BINDING_CURSE, 1);
        }
        super.onUpdate(stack, world, entity, slot, isSelected);
    }
}
